#!/bin/bash
S=1  #scale factor
R0=12345  #seed stream 0 (str0)
((NSTREAMS=1)) # number of streams to generate
((N=1)) 
while ((N<=NSTREAMS))
do
rm streams/str${N}.sql
((i=1)) # i is the query number
cat /dev/null > streams/str${N}.sql
while ((i <= 22))
do
### bash version
#T=`date +'%Y-%m-%d %T.%2N'`
#echo $T
### SQL version
echo "select 'Q${i} starts >>> ' ,current_timestamp(2);" >>  streams/str${N}.sql
if [ $S == 1 ] 
then
echo "case S=1"
./qgen -s 1 -d ${i} >> streams/str${N}.sql
else
((R=R0+i))
echo "case S not 1 and R=${R}"
./qgen -s 1 -d ${i} >> streams/str${N}.sql
fi
echo "select 'Q${i} ends <<< ',current_timestamp(2);" >>  streams/str${N}.sql
((i++))
done
((N++))
done
